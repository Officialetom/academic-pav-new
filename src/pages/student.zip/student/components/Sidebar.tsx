import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUser,
  faHome,
  faChartBar,
  faNewspaper,
  faBookAtlas,
  faMedal,
  faClose,
} from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";

interface props {
  isOpen: boolean;
  closeSidebar: () => void;
}

function Sidebar({ isOpen, closeSidebar }: props) {
  // const navLinksRef = useRef<HTMLDivElement | null>(null);

  return (
    <div className={`sidebar ${isOpen ? "move-sidebar" : ""}`}>
      <div className="title">
        <FontAwesomeIcon
          icon={faClose}
          onClick={closeSidebar}
          className="close-btn"
        />
        <span>AcademyBoard</span>
      </div>
      <div className="navigation">
        <ul>
          <li className="link-active">
            <Link to="#">
              <FontAwesomeIcon icon={faHome} className="f-icon" />
              <span>Dashboard</span>
            </Link>
          </li>
          <li>
            <Link to="#">
              <FontAwesomeIcon icon={faChartBar} className="f-icon" />
              <span>Results</span>
            </Link>
          </li>
          <li>
            <Link to="#">
              <FontAwesomeIcon icon={faUser} className="f-icon" />
              <span>Profile</span>
            </Link>
          </li>
          <li>
            <Link to="#">
              <FontAwesomeIcon icon={faBookAtlas} className="f-icon" />
              <span>Resources</span>
            </Link>
          </li>
          <li>
            <Link to="#">
              <FontAwesomeIcon icon={faMedal} className="f-icon" />
              <span>Scholars</span>
            </Link>
          </li>
          <li>
            <Link to="#">
              <FontAwesomeIcon icon={faNewspaper} className="f-icon" />
              <span>News & Trends</span>
            </Link>
          </li>
        </ul>
      </div>
      <div className="sidebar-footer">
        <div className="footer-title">Academic Year</div>
        <div className="footer-year">2025/2026</div>
      </div>
    </div>
  );
}

export default Sidebar;
