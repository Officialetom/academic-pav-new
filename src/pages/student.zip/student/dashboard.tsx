import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBars, faBell, faGear } from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";
import "./student.css";
import Sidebar from "./components/Sidebar";
import { useState } from "react";

function Dashboard() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => setIsOpen(!isOpen);
  const closeSidebar = () => setIsOpen(false);

  return (
    <div className="student-dashboard">
      <Sidebar isOpen={isOpen} closeSidebar={closeSidebar} />
      <div className="main-content">
        {/* dashboard navbar area */}
        <div className="navbar">
          <div className="nav-item">
            <div className="greetings">
              <span>Welcome back! Academic Pavilion</span>
            </div>
            <div className="info">
              <span>STUDENT ID: STU-123-456</span>
            </div>
          </div>
          <div className="nav-item">
            <Link to="" className="dash-icon">
              <FontAwesomeIcon icon={faBell} className="f-icon" />
            </Link>
            <Link to="" className="dash-icon">
              <FontAwesomeIcon icon={faGear} className="f-icon" />
            </Link>
            <div className="profile">
              <span>AP</span>
            </div>
            <FontAwesomeIcon
              icon={faBars}
              onClick={toggleSidebar}
              className="toggle-btn"
            />
          </div>
        </div>
        {/* dashboard main content area */}
        <div className="content">
          <div className="dash-card p-1 mb-1"></div>
          <div className="dash-card p-1"></div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
